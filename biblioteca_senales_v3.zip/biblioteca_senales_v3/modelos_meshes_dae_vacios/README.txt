/*USO DE LA CARPETA*/

Se trata de un repositorio de modelos en sdf de la extructura de las
señales verticales sin texturas aplicadas en caso de que se quisiese
realizar una señal desde un nivel más bajo, sin embargo, se recomienda
partir de algun modelo de señal ya terminado y modificarlo para evitar
un costoso debugging