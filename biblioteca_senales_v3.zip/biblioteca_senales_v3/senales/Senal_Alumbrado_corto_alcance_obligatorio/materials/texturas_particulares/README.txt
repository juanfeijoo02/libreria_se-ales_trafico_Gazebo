/*INSTRUCCIONES USO DE LA CARPETA texturas_particulares EN CASO DE SER NECESARIO*/

Introducir en esta carpeta si fuera necesario las texturas particulares de cada
señal, si bien se recomienda (y es el procedimiento empleado por el autor), hacer 
uso de las carpetas generales del workspace biblioteca_senales_V<> para simplificar
la adicion de nuevas texturas a la par que se reduce la redundancia en texturas
recurrentes encontradas en texturas_genericas

<!-- en caso de que se quisiese introducir una textura en el apartado
de texturas_particulares, deberia referenciarse este path con la inclusion
de la siguiente linea -->
<!--
<uri>model://Senal_situacion_paso_peatones/materials/texturas_particulares</uri>
-->
dentro de la estructura del model.sdf

sdf
    model
        link
            visual
                material
                    script <--