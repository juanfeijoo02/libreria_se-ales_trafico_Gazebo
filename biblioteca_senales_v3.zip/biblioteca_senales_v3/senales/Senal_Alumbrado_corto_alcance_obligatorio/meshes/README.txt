#in this folder meshes that need to be included in the model description file aka model.sdf 
#are kept, in the original version of the autor Juan Feijoo only one mesh is kept, the thin 
#cilinder on which the png with circular mask is proyected.

#Procedure on how to add new meshes and reference them to the model.sdf is carefully described
#in the comments of the model.sdf file, however is advisable to replicate the current working
#scheme and try adapting it to particular requirements instead of building the structure from 
#a null begining.
#The author