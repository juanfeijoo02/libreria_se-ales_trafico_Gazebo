# ejecutar en terminal para que gazebo sea capaz de acceder a la libreria del modelo 

export GAZEBO_MODEL_PATH=/home/juan/Desktop/TFG_Juan_Feijoo_Rodriguez/Gazebo_world/biblioteca_senales_V1

#exitoso en la inclusion de links para la formacion de una senal basica empleando un cilindro estrecho
#y un paralelepipedo de poco grosor sobre el que proyectar el png
#intento eliminacion de informacion dinamica excesiva en la descripcion sdf
#apartados eliminados (los señalados en <--, lo otro es su "path" dentro de la estructura sdf)
sdf
    model
        link
            inertial    <--
            collision
                surface <--
        joint
            physics     <--
#inclusion de textura para el poste metalico de soporte que finalmente se ha escogido como un paralelepipedo
#inclusion de una chapa en la parte trasera para que la señal solamente se pueda visualizar desde un sentido

#para evitar la simulacion  de la fisica de la señal (lo cual no nos interesa, solo su aspecto visual)
#hay que poner a 1 <static>1</static> al final del codigo en el siguiente "path"

sdf 
    model
        <static>1</static> <-- (al final)

#se eliminan los siguientes apartados
sdf
    model   
        link 
            collision
                laser_retro     <--
                max_contacts    <--
#se referencian las texturas de forma relativa y externa al modelo de la señal en cuestion
#de tal forma que estas se encuentren en dos carpetas justo un escalon por debajo del fichero 
#biblioteca_senales
